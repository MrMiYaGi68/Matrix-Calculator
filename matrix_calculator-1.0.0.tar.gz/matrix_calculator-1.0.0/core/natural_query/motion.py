from __future__ import annotations

import re

from core.formatting import format_number
from core.natural_query.common import format_local_result
from core.natural_query.types import NaturalQueryResult


def _number_before_unit(text: str, unit_pattern: str) -> float | None:
    matches = re.findall(rf"(?P<value>\d+(?:\.\d+)?)\s*(?:{unit_pattern})", text)
    if not matches:
        return None
    return float(matches[0])


def _extract_motion_values(normalized: str) -> tuple[float | None, float | None, float | None]:
    speed = _number_before_unit(normalized, r"km/h|kmh|m/s")
    time_value = _number_before_unit(normalized, r"stunden|stunde|h|sekunden|sekunde|s")
    distance = _number_before_unit(normalized, r"kilometer|km|meter|m")
    return distance, speed, time_value


def solve_motion_query(normalized: str, values: list[float]) -> NaturalQueryResult | None:
    speed_distance_match = re.search(
        r"(?:mit|bei)\s+(?P<speed>\d+(?:\.\d+)?)\s*(?:km/h|kmh|m/s)?(?:.*?)(?P<time>\d+(?:\.\d+)?)\s*(?:stunden|stunde|h|sekunden|s)(?:.*?)(?:wie weit|welche strecke|wie viele kilometer)",
        normalized,
    )
    if speed_distance_match:
        speed = float(speed_distance_match.group("speed"))
        time_value = float(speed_distance_match.group("time"))
        value = speed * time_value
        expression = f"{format_number(speed)}*{format_number(time_value)}"
        explanation = "Die Strecke ist Geschwindigkeit mal Zeit."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    distance, labelled_speed, labelled_time = _extract_motion_values(normalized)

    if "wie weit" in normalized and labelled_speed is not None and labelled_time is not None:
        speed = labelled_speed
        time_value = labelled_time
        value = speed * time_value
        expression = f"{format_number(speed)}*{format_number(time_value)}"
        explanation = "Die Strecke ist Geschwindigkeit mal Zeit."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    speed_time_patterns = [
        r"(?:f[üu]r|für|bei)\s+(?P<distance>\d+(?:\.\d+)?)\s*(?:km|kilometer|m|meter).*(?:mit|bei)\s+(?P<speed>\d+(?:\.\d+)?)\s*(?:km/h|kmh|m/s).*(?:wie lange|wie viel zeit|wie viele stunden|brauche ich)",
        r"(?:mit|bei)\s+(?P<speed>\d+(?:\.\d+)?)\s*(?:km/h|kmh|m/s).*(?:bei|f[üu]r)\s+(?P<distance>\d+(?:\.\d+)?)\s*(?:km|kilometer|m|meter).*(?:wie lange|wie viel zeit|wie viele stunden|brauche ich)",
        r"(?:wie lange|wie viel zeit|wie viele stunden|brauche ich).*(?:f[üu]r|für|bei)\s+(?P<distance>\d+(?:\.\d+)?)\s*(?:km|kilometer|m|meter).*(?:mit|bei)\s+(?P<speed>\d+(?:\.\d+)?)\s*(?:km/h|kmh|m/s)",
        r"(?:wie lange|wie viel zeit|wie viele stunden|brauche ich).*(?:mit|bei)\s+(?P<speed>\d+(?:\.\d+)?)\s*(?:km/h|kmh|m/s).*(?:f[üu]r|für|bei)\s+(?P<distance>\d+(?:\.\d+)?)\s*(?:km|kilometer|m|meter)",
    ]
    for pattern in speed_time_patterns:
        speed_time_match = re.search(pattern, normalized)
        if speed_time_match:
            distance = float(speed_time_match.group("distance"))
            speed = float(speed_time_match.group("speed"))
            if speed != 0:
                value = distance / speed
                expression = f"{format_number(distance)}/{format_number(speed)}"
                explanation = "Die Zeit ist Strecke geteilt durch Geschwindigkeit."
                return NaturalQueryResult(*format_local_result(expression, value, explanation))

    if any(term in normalized for term in ["wie lange", "wie viel zeit", "wie viele stunden", "brauche ich"]):
        if distance is None or labelled_speed is None:
            return None
        speed = labelled_speed
        if speed != 0:
            value = distance / speed
            expression = f"{format_number(distance)}/{format_number(speed)}"
            explanation = "Die Zeit ist Strecke geteilt durch Geschwindigkeit."
            return NaturalQueryResult(*format_local_result(expression, value, explanation))

    if any(term in normalized for term in ["geschwindigkeit", "tempo", "wie schnell"]):
        if distance is None or labelled_time is None:
            return None
        time_value = labelled_time
        if time_value != 0:
            value = distance / time_value
            expression = f"{format_number(distance)}/{format_number(time_value)}"
            explanation = "Geschwindigkeit ist Strecke geteilt durch Zeit."
            return NaturalQueryResult(*format_local_result(expression, value, explanation))

    return None
