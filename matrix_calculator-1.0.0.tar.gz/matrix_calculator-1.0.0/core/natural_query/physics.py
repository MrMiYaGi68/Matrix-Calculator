from __future__ import annotations

import re

from core.formatting import format_number
from core.natural_query.common import format_local_result
from core.natural_query.types import NaturalQueryResult


def _number_before_unit(text: str, unit_pattern: str) -> float | None:
    match = re.search(rf"(?P<value>\d+(?:\.\d+)?)\s*(?:{unit_pattern})", text)
    return float(match.group("value")) if match else None


def solve_physics_query(normalized: str, values: list[float]) -> NaturalQueryResult | None:
    if any(term in normalized for term in ["arbeit", "arbeit in joule"]) and len(values) >= 2:
        force = values[0]
        distance = values[1]
        value = force * distance
        expression = f"{format_number(force)}*{format_number(distance)}"
        explanation = "Arbeit ist Kraft mal Weg."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    voltage_current_power = re.search(r"(?P<volt>\d+(?:\.\d+)?)\s*v.*(?P<amp>\d+(?:\.\d+)?)\s*a", normalized)
    if any(term in normalized for term in ["leistung", "watt"]) and voltage_current_power:
        volt = float(voltage_current_power.group("volt"))
        amp = float(voltage_current_power.group("amp"))
        value = volt * amp
        expression = f"{format_number(volt)}*{format_number(amp)}"
        explanation = "Elektrische Leistung ist Spannung × Strom."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    if any(term in normalized for term in ["leistung", "watt", "wie viel leistung"]):
        work = _number_before_unit(normalized, r"joule|j")
        time_value = _number_before_unit(normalized, r"sekunden|sekunde|s")
        if work is None or time_value is None or time_value == 0:
            return None
        value = work / time_value
        expression = f"{format_number(work)}/{format_number(time_value)}"
        explanation = "Leistung ist Arbeit geteilt durch Zeit."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    if any(term in normalized for term in ["beschleunigung", "wie stark beschleunigt"]):
        velocity = _number_before_unit(normalized, r"m/s|km/h|kmh")
        time_value = _number_before_unit(normalized, r"sekunden|sekunde|s")
        if velocity is None or time_value is None or time_value == 0:
            return None
        value = velocity / time_value
        expression = f"{format_number(velocity)}/{format_number(time_value)}"
        explanation = "Beschleunigung ist Geschwindigkeitsänderung geteilt durch Zeit."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    density_numbers = [
        float(item)
        for item in re.findall(r"(?<![a-z])\d+(?:\.\d+)?(?![a-z])", normalized.replace("m3", " ").replace("cm3", " "))
    ]
    if "dichte" in normalized:
        mass = _number_before_unit(normalized, r"kg|g")
        volume = _number_before_unit(normalized, r"m3|m\^3|cm3|cm\^3|l")
        if mass is None or volume is None:
            return None
        if volume != 0:
            value = mass / volume
            expression = f"{format_number(mass)}/{format_number(volume)}"
            explanation = "Dichte ist Masse geteilt durch Volumen."
            return NaturalQueryResult(*format_local_result(expression, value, explanation))

    force_numbers = [
        float(item)
        for item in re.findall(r"(?<![a-z])\d+(?:\.\d+)?(?![a-z])", normalized.replace("m/s2", " ").replace("m/s^2", " "))
    ]
    if "kraft" in normalized:
        mass = _number_before_unit(normalized, r"kg|g")
        accel = _number_before_unit(normalized, r"m/s2|m/s\^2")
        if mass is None or accel is None:
            return None
        value = mass * accel
        expression = f"{format_number(mass)}*{format_number(accel)}"
        explanation = "Kraft ist Masse mal Beschleunigung."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    return None
