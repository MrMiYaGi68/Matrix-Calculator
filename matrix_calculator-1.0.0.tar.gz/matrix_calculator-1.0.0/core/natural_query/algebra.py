from __future__ import annotations

import math
import re

from core.formatting import format_number
from core.natural_query.common import format_local_result
from core.natural_query.types import NaturalQueryResult


def solve_equation_query(normalized: str) -> NaturalQueryResult | None:
    quadratic_match = re.search(
        r"(?P<a>-?\d+(?:\.\d+)?)x\^?2\s*(?P<op1>[+-])\s*(?P<b>\d+(?:\.\d+)?)x\s*(?P<op2>[+-])\s*(?P<c>\d+(?:\.\d+)?)\s*=\s*0",
        normalized,
    )
    if quadratic_match:
        a = float(quadratic_match.group("a"))
        b = float(quadratic_match.group("b")) * (-1 if quadratic_match.group("op1") == "-" else 1)
        c = float(quadratic_match.group("c")) * (-1 if quadratic_match.group("op2") == "-" else 1)
        if a != 0:
            discriminant = b * b - 4 * a * c
            if discriminant >= 0:
                root = math.sqrt(discriminant)
                x1 = (-b + root) / (2 * a)
                x2 = (-b - root) / (2 * a)
                expression = f"x1={format_number(x1)}, x2={format_number(x2)}"
                answer = f"x1 = {format_number(x1)}, x2 = {format_number(x2)}"
                explanation = "Die quadratische Gleichung wurde mit der Mitternachtsformel gelöst."
                return NaturalQueryResult(expression, answer, explanation)

    linear_match = re.search(
        r"(?:(?P<a>-?\d+(?:\.\d+)?)\s*\*?\s*)?x(?!\s*\^?2)\s*(?P<op>[+-])\s*(?P<b>\d+(?:\.\d+)?)\s*=\s*(?P<c>-?\d+(?:\.\d+)?)",
        normalized,
    )
    if linear_match:
        a = float(linear_match.group("a") or 1)
        b = float(linear_match.group("b"))
        c = float(linear_match.group("c"))
        if linear_match.group("op") == "-":
            b = -b
        if a != 0:
            value = (c - b) / a
            expression = f"({format_number(c)}-{format_number(b)})/{format_number(a)}"
            explanation = "Die lineare Gleichung wird nach x umgestellt: x = (c - b) / a."
            return NaturalQueryResult(*format_local_result(expression, value, explanation))

    system_match = re.search(
        r"(?P<a1>-?\d+(?:\.\d+)?)x\s*(?P<op1>[+-])\s*(?P<b1>\d+(?:\.\d+)?)y\s*=\s*(?P<c1>-?\d+(?:\.\d+)?).*(?P<a2>-?\d+(?:\.\d+)?)x\s*(?P<op2>[+-])\s*(?P<b2>\d+(?:\.\d+)?)y\s*=\s*(?P<c2>-?\d+(?:\.\d+)?)",
        normalized,
    )
    if system_match:
        a1 = float(system_match.group("a1"))
        b1 = float(system_match.group("b1")) * (-1 if system_match.group("op1") == "-" else 1)
        c1 = float(system_match.group("c1"))
        a2 = float(system_match.group("a2"))
        b2 = float(system_match.group("b2")) * (-1 if system_match.group("op2") == "-" else 1)
        c2 = float(system_match.group("c2"))
        det = a1 * b2 - a2 * b1
        if det != 0:
            x_value = (c1 * b2 - c2 * b1) / det
            y_value = (a1 * c2 - a2 * c1) / det
            expression = f"x={format_number(x_value)}, y={format_number(y_value)}"
            answer = f"x = {format_number(x_value)}, y = {format_number(y_value)}"
            explanation = "Das lineare Gleichungssystem wurde mit dem Determinantenverfahren gelöst."
            return NaturalQueryResult(expression, answer, explanation)

    x_right_match = re.search(r"x\s*=\s*(?P<value>-?\d+(?:\.\d+)?)", normalized)
    if x_right_match:
        value = float(x_right_match.group("value"))
        expression = format_number(value)
        explanation = "Die Gleichung ist bereits nach x aufgelöst."
        return NaturalQueryResult(*format_local_result(expression, value, explanation))

    return None


def solve_fraction_query(normalized: str) -> NaturalQueryResult | None:
    fraction_match = re.search(
        r"(?P<a>\d+)\s*/\s*(?P<b>\d+)\s*(?P<op>[+\-*/])\s*(?P<c>\d+)\s*/\s*(?P<d>\d+)",
        normalized,
    )
    if not fraction_match:
        return None
    a = float(fraction_match.group("a"))
    b = float(fraction_match.group("b"))
    c = float(fraction_match.group("c"))
    d = float(fraction_match.group("d"))
    op = fraction_match.group("op")
    if b == 0 or d == 0:
        return None
    left = a / b
    right = c / d
    value = {
        "+": left + right,
        "-": left - right,
        "*": left * right,
        "/": left / right if right != 0 else None,
    }[op]
    if value is None:
        return None
    expression = f"({format_number(a)}/{format_number(b)}){op}({format_number(c)}/{format_number(d)})"
    explanation = "Die Bruchrechnung wurde als Rechenoperation zwischen zwei Brüchen ausgewertet."
    return NaturalQueryResult(*format_local_result(expression, value, explanation))
