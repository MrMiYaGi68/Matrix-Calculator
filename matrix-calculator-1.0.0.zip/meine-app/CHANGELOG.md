# Changelog

## 1.0.0 - 2026-04-27

- Added project packaging metadata via `pyproject.toml`.
- Declared PySide6 as an install dependency so the app starts after a standard install.
- Removed persistent OpenAI API key storage from application settings.
- Hardened settings file permissions to owner-read/write only.
- Made the desktop launcher independent of absolute user paths.
- Added security, privacy, architecture and operations documentation.
- Extracted settings persistence and OpenAI network access from the main window
  into dedicated core services.
- Extracted assistant flow decisions into a UI-independent service.
- Expanded the local natural-language assistant for German and English, including
  written numbers, numeric abbreviations, relationship word problems and English
  smalltalk/chat abbreviations.
